import timesynth as ts
import numpy as np

import matplotlib.pyplot as plt

import sys

# ts_len = 100
ts_len=100000

dv_lag=True # True if non-zero a[1] coeff.

train_test_iid = False

if train_test_iid:
	seed_ = 42
else:
	seed_ = 131

if dv_lag:
	#[[c0_d0, c1_d0], [c0_d1, c1_d1]]
	#for scenario 5, need to first run scenario 1, then scenario 5 and then concatenate.
	coeffs={1: [[0.3, -0.1, 0.8, 0.1, 0., 0., 0., 0.],[0., 0., 0., 0., 0.15, -0.05, 0.55, 0.2]],
			2: [[0.3, -0.1, 0.8, 0.1, 0., 0., 0.5, 0.],[0., 0., 0., 0., 0.15, -0.05, 0.55, 0.2]],
			3: [[0.3, -0.1, 0.8, 0.1, 0., 0., 0., 0.],[0., 0., 0.5, 0., 0.15, -0.05, 0.55, 0.2]],
			4: [[0.3, -0.1, 0.8, 0.1, 0., 0., 0.5, 0.],[0., 0., 0.5, 0., 0.15, -0.05, 0.55, 0.2]],
			5: [[0.2, -0.05, 0.5, 0.6, 0., 0., 0., 0.],[0., 0., 0., 0., 0.5, -0.08, 0.35, 0.4]],
			6: [[0.3, -0.1, 0.8, 0.1],[0.15, -0.05, 0.55, 0.2]],
			7: [[0.3, -0.1, 0.8, 0.1],[0.15, -0.05, 0.55, 0.2]],
			8: [[0.3, -0.1, 0.8, 0.1],[0.15, -0.05, 0.55, 0.2]]}
	
else:
	coeffs={1: [[0.3, 0., 0.8, 0.1, 0., 0., 0., 0.],[0., 0., 0., 0., 0.15, 0., 0.55, 0.2]],
			2: [[0.3, 0., 0.8, 0.1, 0., 0., 0.5, 0.],[0., 0., 0., 0., 0.15, 0.0, 0.55, 0.2]],
			3: [[0.3, 0., 0.8, 0.1, 0., 0., 0., 0.],[0., 0., 0.5, 0., 0.15, 0.0, 0.55, 0.2]],
			4: [[0.3, 0., 0.8, 0.1, 0., 0., 0.5, 0.],[0., 0., 0.5, 0., 0.15, 0.0, 0.55, 0.2]],
			5: [[0.2, 0., 0.5, 0.6, 0., 0., 0., 0.],[0., 0., 0., 0., 0.5, 0., 0.35, 0.4]],
			6: [[0.3, 0., 0.8, 0.1],[0.15, 0., 0.55, 0.2]],
			7: [[0.3, 0., 0.8, 0.1],[0.15, 0., 0.55, 0.2]],
			8: [[0.3, 0., 0.8, 0.1],[0.15, 0., 0.55, 0.2]]}


np.random.seed(seed_)


def plot_data(times, samples):

	plt.plot(times[20:1000], samples[0][20:1000], label='state')
	#plt.plot(times[20:10000], samples[1][20:10000], label='control')
	plt.legend()
	plt.xlabel('Time')
	plt.ylabel('Magnitude')
	plt.title('10th-order NARMA Series');
	plt.show()



def narma_1d():
	for i in range(len(coeffs[scenario])):
		print(i)
		time_sampler = ts.TimeSampler(stop_time=ts_len)
		times = time_sampler.sample_regular_time(resolution=1.0)
		narma_signal= ts.signals.NARMA(order=10,coefficients=coeffs[i]) #,seed=42)
		series = ts.TimeSeries(narma_signal)
		samples, _, _ = series.sample(times)
		plot_data(times,samples)
		this_data=np.concatenate((np.expand_dims(samples[0], axis=0), np.expand_dims(samples[1],axis=0)), axis=0)
		if i==0:
			data = this_data
		else:
			data=np.concatenate((data,this_data),axis=0)
	return data

def narma_2d(scenario_num):
	time_sampler = ts.TimeSampler(stop_time=ts_len)
	times = time_sampler.sample_regular_time(resolution=1.0)
	narma_signal= ts.signals.NARMA2DCorrCV(order=10,coefficients=coeffs[scenario_num],afterEvery=100,seed=seed_)
	series = ts.TimeSeries(narma_signal)
	samples, _, _ = series.sample(times)
	print(np.shape(samples))
	#plot_data(times,samples)

	#saved like d0, d1, c0, c1, alpha
	train_data=np.concatenate((np.expand_dims(samples[0], axis=0), np.expand_dims(samples[1],axis=0), 
		np.expand_dims(samples[2], axis=0), np.expand_dims(samples[3],axis=0), np.expand_dims(samples[4],axis=0)), axis=0)
	test_data=np.concatenate((np.expand_dims(samples[5], axis=0), np.expand_dims(samples[6],axis=0), 
		np.expand_dims(samples[7], axis=0), np.expand_dims(samples[8],axis=0), np.expand_dims(samples[9],axis=0)), axis=0)
	return train_data, test_data


scenario_num=int(sys.argv[1])

train_data, test_data = narma_2d(scenario_num)
if dv_lag:
	# filename='data/narma_2d_'+str(scenario_num)+'_n0.csv'
	train_filename='narma_2d_'+str(scenario_num)+'_n0.csv'
	test_filename='narma_2d_test_'+str(scenario_num)+'_n0.csv'

else:
	filename='data/narma_2d_'+str(scenario_num)+'_0.csv'
header='DV1,DV2,CV1,CV2,Alpha\n'
with open(train_filename,'a') as f:
	f.write(header)

with open(train_filename,'ab') as f:
	np.savetxt(f, np.transpose(train_data),delimiter=',')

header='DV1,DV2,CV1,CV2,Alpha\n'
with open(test_filename,'a') as f:
	f.write(header)

with open(test_filename,'ab') as f:
	np.savetxt(f, np.transpose(test_data),delimiter=',')
