import numpy as np
from .base_signal import BaseSignal
import sys

__all__ = ['NARMA2DCorrCV']


class NARMA2DCorrCV(BaseSignal):
    r"""Non-linear Autoregressive Moving Average generator.
    		
    An n-th order signal generator of the NARMA class, as defined in [1]_:
    .. \math:: y(k+1) = a[0] * y(k) + a[1] * y(k) * \sum_{i=0}^{n-1} y(k-i) + a[2] * u(k-(n-1)) * u(k) + a[3]
    
    where u is generated from Uniform(0, 0.5).
    
    NOTE: Only supports regular time samples.
    
    Parameters
    ----------
    order : int (default 10)
        The order (n) of non-linear interactions as described in the formula above.
    coefficients : iterable (default [0.3, 0.05, 1.5, 0.1])
        The coefficients denoted by iterable `a` in the formula above. As in [1]_.
    initial_condition : iterable or None (default None)
        An array of starting values of y(k-n) until y(k). The default is an array of zeros.
    seed : int
        Use this seed to recreate any of the internal errors.
        
    Attributes
    ----------
    errors : numpy array or None
        Random number sequence that was used to generate last NARMA sequence.
    
    References
    ----------
    .. [1] http://ieeexplore.ieee.org.ezp-prod1.hul.harvard.edu/stamp/stamp.jsp?arnumber=846741
    
    """
    # [0.3, 0.05, 1.5, 0.1]
    def __init__(self, order=10, coefficients=[0.3, 0.05, 1.5, 0.1], initial_condition=None,
                 error_initial_condition=None, seed=42, num_regimes = 8, afterEvery = 10):
        self.vectorizable = True
        self.order = order
        self.coefficients = coefficients 
        print(self.coefficients)
        #self.random = np.random.RandomState(seed)
        
        # Store initial conditions
        if initial_condition is None:
            self.initial_condition1 = np.zeros(order)
            self.initial_condition2 = np.zeros(order)
        else:
            # TODO: handle 2d case
            self.initial_condition = np.array(initial_condition)

        self.beta_dict = {}
        self.num_regimes = num_regimes
        self.afterEvery = afterEvery # sampling rate
        self.isPresentTrain = {}

        # You may provide an error initial condition
        if error_initial_condition is None:
            self.error_initial_condition1 = np.random.uniform(0, 0.5, size=order)
            self.error_initial_condition2 = np.random.uniform(0, 0.5, size=order)
        else:
            # TODO: handle 2d case
            self.error_initial_condition = error_initial_condition

    def getBetaDict(self):

        for i in range(1, self.num_regimes+1):
            for j in range(1, self.num_regimes+1):
                self.beta_dict[i,j] = [[np.random.uniform(0.5, 0.79), np.random.uniform(-0.1, 0.1)],
                                    [np.random.uniform(0.5, 0.79), np.random.uniform(-0.1, 0.1)]]
        print(self.beta_dict)
        sys.exit()
        
    def _next_value(self, values1, values2, rands1, rands2, index):
        """Internal short-hand method to calculate next value."""
        # Short-hand parameters
        n = self.order
        a1 = self.coefficients[0]
        a2 = self.coefficients[1]
        
        
        # Get value arrays
        i = index
        y1 = values1
        y2 = values2
        u1 = rands1
        u2 = rands2
        
        # Compute next values
        y1_next = a1[0] * y1[i-1] + a1[1] * y1[i-1] * np.sum(y1[i-n:i]) + a1[2] * u1[i-n] * u1[i] + a1[3] + a1[4] * y2[i-1] + a1[5] * y2[i-1] * np.sum(y2[i-n:i]) + a1[6] * u2[i-n] * u2[i] + a1[7]
        
        y2_next = a2[0] * y1[i-1] + a2[1] * y1[i-1] * np.sum(y1[i-n:i]) + a2[2] * u1[i-n] * u1[i] + a2[3] + a2[4] * y2[i-1] + a2[5] * y2[i-1] * np.sum(y2[i-n:i]) + a2[6] * u2[i-n] * u2[i] + a2[7]
        
        return y1_next, y2_next
        
    def sample_next(self, time, samples, errors):
        """This method is not available for NARMA, due to internal error sampling."""
        raise NotImplementedError("NARMA can only be sampled vectorized.")


    def createInput(self, input1, input2, train=True):

        cv_1 = []
        cv_2 = []
        alphas = []
        
        train_min, train_max=0.1,0.3
        test_min, test_max=0.0,0.2
        if train:
            alpha=np.random.uniform(train_min,train_max)
        else:
            alpha=np.random.uniform(test_min,test_max)

        for i in range(input1.shape[0]):
            if(i%self.afterEvery == 0 and np.random.uniform(0, 1.0)>0.5):
                print('changing alpha')
                print(i)
                if train:
                    alpha=np.random.uniform(train_min,train_max)
                else:
                    alpha=np.random.uniform(test_min,test_max)
                print(alpha)

            alphas.append(alpha)
            value_1 = input1[i]
            value_2 = alpha*input1[i] + (1-alpha)*input2[i]
            cv_1.append(value_1)
            cv_2.append(value_2) 

        return np.array(cv_1), np.array(cv_2), alphas

    def sample_vectorized(self, times):
        """Samples for all time points in input
        
        Internalizes Uniform(0, 0.5) random distortion for u.

        Parameters
        ----------
        times: array like
            all time stamps to be sampled
        
        Returns
        -------
        samples : numpy array
            samples for times provided in time_vector

        """
        # Set bounds
        start = self.initial_condition1.shape[0]
        
        # Get relevant arrays
        inits1 = self.initial_condition1
        inits2 = self.initial_condition2
        rand_inits1 = self.error_initial_condition1
        rand_inits2 = self.error_initial_condition2

        cv3 = np.random.uniform(0, 0.9, size=times.shape[0])
        cv4 = np.random.uniform(0, 0.9, size=times.shape[0])
        input_1, input_2, alphas_train = self.createInput(cv3, cv4, train=True)

        cv3 = np.random.uniform(0, 0.9, size=times.shape[0])
        cv4 = np.random.uniform(0, 0.9, size=times.shape[0])
        input_1_test, input_2_test, alphas_test = self.createInput(cv3, cv4, train=False)

        rands1 = np.concatenate((rand_inits1, input_1))
        rands2 = np.concatenate((rand_inits2, input_2))

        rands1_test = np.concatenate((rand_inits1, input_1_test))
        rands2_test = np.concatenate((rand_inits2, input_2_test))

        values1 = np.concatenate((inits1, np.zeros(times.shape[0])))
        values2 = np.concatenate((inits2, np.zeros(times.shape[0])))

        values1_test = np.concatenate((inits1, np.zeros(times.shape[0])))
        values2_test = np.concatenate((inits2, np.zeros(times.shape[0])))
        
        # Sample step-wise
        end = values1.shape[0]
        for t in range(start, end):
            values1[t], values2[t] = self._next_value(values1, values2, rands1, rands2, t)
            values1_test[t], values2_test[t] = self._next_value(values1_test, values2_test, rands1_test, rands2_test, t)
        
        # Store values for later retrieval
        self.errors1 = rands1[start:]
        self.errors2 = rands2[start:]
        errors1_test = rands1_test[start:]
        errors2_test = rands2_test[start:]

        # Return trimmed values (exclude initial condition)
        samples1 = values1[start:]
        samples2 = values2[start:]
        samples1_test = values1_test[start:]
        samples2_test = values2_test[start:]

        return samples1, samples2, self.errors1, self.errors2, alphas_train, samples1_test, samples2_test, errors1_test, errors2_test, alphas_test
