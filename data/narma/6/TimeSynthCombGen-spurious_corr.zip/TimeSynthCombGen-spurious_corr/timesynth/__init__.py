from .timeseries import TimeSeries
from . import signals
from . import noise
from .timesampler import TimeSampler

name = "timesynth"

