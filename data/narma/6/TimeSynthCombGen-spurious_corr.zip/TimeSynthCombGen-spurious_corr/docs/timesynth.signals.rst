timesynth.signals package
=========================

Submodules
----------

timesynth.signals.ar module
---------------------------

.. automodule:: timesynth.signals.ar
    :members:
    :undoc-members:
    :show-inheritance:

timesynth.signals.base_signal module
------------------------------------

.. automodule:: timesynth.signals.base_signal
    :members:
    :undoc-members:
    :show-inheritance:

timesynth.signals.car module
----------------------------

.. automodule:: timesynth.signals.car
    :members:
    :undoc-members:
    :show-inheritance:

timesynth.signals.dde module
----------------------------

.. automodule:: timesynth.signals.dde
    :members:
    :undoc-members:
    :show-inheritance:

timesynth.signals.gaussian_process module
-----------------------------------------

.. automodule:: timesynth.signals.gaussian_process
    :members:
    :undoc-members:
    :show-inheritance:

timesynth.signals.ode module
----------------------------

.. automodule:: timesynth.signals.ode
    :members:
    :undoc-members:
    :show-inheritance:

timesynth.signals.pseudoperiodic module
---------------------------------------

.. automodule:: timesynth.signals.pseudoperiodic
    :members:
    :undoc-members:
    :show-inheritance:

timesynth.signals.sinusoidal module
-----------------------------------

.. automodule:: timesynth.signals.sinusoidal
    :members:
    :undoc-members:
    :show-inheritance:


Module contents
---------------

.. automodule:: timesynth.signals
    :members:
    :undoc-members:
    :show-inheritance:
