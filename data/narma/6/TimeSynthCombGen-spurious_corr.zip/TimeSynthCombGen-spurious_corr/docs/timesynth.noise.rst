timesynth.noise package
=======================

Submodules
----------

timesynth.noise.base_noise module
---------------------------------

.. automodule:: timesynth.noise.base_noise
    :members:
    :undoc-members:
    :show-inheritance:

timesynth.noise.gaussian_noise module
-------------------------------------

.. automodule:: timesynth.noise.gaussian_noise
    :members:
    :undoc-members:
    :show-inheritance:

timesynth.noise.red_noise module
--------------------------------

.. automodule:: timesynth.noise.red_noise
    :members:
    :undoc-members:
    :show-inheritance:


Module contents
---------------

.. automodule:: timesynth.noise
    :members:
    :undoc-members:
    :show-inheritance:
