timesynth package
=================

Subpackages
-----------

.. toctree::

    timesynth.noise
    timesynth.signals
    timesynth.timesampler

Submodules
----------

timesynth.timeseries module
---------------------------

.. automodule:: timesynth.timeseries
    :members:
    :undoc-members:
    :show-inheritance:


Module contents
---------------

.. automodule:: timesynth
    :members:
    :undoc-members:
    :show-inheritance:
